// CalculatorPanel.java
// Caitlin Coggins

//awt
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CalculatorPanel extends JPanel implements ActionListener
{
    public JButton[] numberButtons = new JButton[10];
    public String buttonName;
    
    public CalculatorPanel()
    {
        super( new BorderLayout() );
        
        add(createTextField(), BorderLayout.NORTH);
        
        add(createButtons(), BorderLayout.CENTER);
    }
    
    public JTextField createTextField( String buttonName )
    {
        if( buttonName.equals(""))
        {
            JTextField blank = new JTextField();
            blank.setEditable(false);
            return blank;
        }
        
        else
        {
            JTextField button = new JTextField("You pressed " + buttonName);
            button.setEditable(false);
            return button;
        }
    }
     
    public JTextField createTextField()
    {
        JTextField empty = createTextField("");
        
        return empty;
    }
    
    public JPanel createButtons()
    {
        JPanel buttons = new JPanel (new GridLayout(4, 4));
        
        // creates a button for each number key on the calculator and adds an ActionListener
        for( int i=0; i<numberButtons.length; ++i)
        {
            numberButtons[i] = new JButton(Integer.toString(i));
            numberButtons[i].addActionListener(this);
        }
        
        
        JButton plusButton = new JButton("+");
        plusButton.addActionListener(this);
        
        JButton minusButton = new JButton("-");
        
        
        JButton multiplyButton = new JButton("x");
        
        
        JButton divideButton = new JButton("/");
        
        
        JButton decimalButton = new JButton(".");
        
        
        JButton equalsButton = new JButton("=");
        
        // All buttons are added in the order they will appear on the calculator
        buttons.add(numberButtons[7]);
        buttons.add(numberButtons[8]);
        buttons.add(numberButtons[9]);
        buttons.add(plusButton);
        buttons.add(numberButtons[4]);
        buttons.add(numberButtons[5]);
        buttons.add(numberButtons[6]);
        buttons.add(minusButton);
        buttons.add(numberButtons[1]);
        buttons.add(numberButtons[2]);
        buttons.add(numberButtons[3]);
        buttons.add(multiplyButton);
        buttons.add(numberButtons[0]);
        buttons.add(decimalButton);
        buttons.add(equalsButton);
        buttons.add(divideButton);
        
        return buttons;
        
    }
    
    public void actionPerformed( ActionEvent e)
    {
        JButton buttonPressed = (JButton)e.getSource();
		
        if ( buttonPressed.equals(numberButtons[0]) )
			createTextField("0");
            
        else if ( buttonPressed.equals(numberButtons[1]) )
            createTextField("1");
            
        else
            createTextField("");
	}
}