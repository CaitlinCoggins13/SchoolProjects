// CalculatorApplication.java
// Caitlin Coggins

/**
 * Main application to show an CalculatorFrame
 **/

// swing
import javax.swing.JFrame;

public class CalculatorApplication
{
    /**
     * main method starts the program
     **/
    public static void main( String[] args )
    {
        // create a new JFrame to hold IceCreamPanel
        JFrame calculatorFrame = new JFrame();

        // set size
        calculatorFrame.setSize( 600, 400 );

        // adds a CalculatorPanel
        calculatorFrame.add( new CalculatorPanel() );

        // exit normally on closing the window
        calculatorFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        // show frame
        calculatorFrame.setVisible( true );
    }
}
