// CalculatorApplet.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * CalculatorApplet .
 * @author Caitlin Coggins
 **/
public class CalculatorApplet extends JApplet
{
	
	/**
	 * Constructor, invoked for a new instance
	 **/
	public CalculatorApplet()
	{
		// call super constructor
		super();
	}
	
	/**
	 * special method invoked when applet is created; looks for parameter type with value menu to show a menu.
	 **/
	public void start()
	{
        // creat a CalculatorPanel and add it
        add( new CalculatorPanel() );
	}
    
	
}