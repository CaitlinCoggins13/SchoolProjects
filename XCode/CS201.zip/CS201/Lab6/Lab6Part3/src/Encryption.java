public class Encryption{
	private String file;
	private int key;
	//public char[] alphabetLow;
	//public char[] alphabetUpper;
	//private char[] fileChar;
	public Encryption(){
		//alphabetLow = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		//alphabetUpper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
	}
	public String encrypt(String file, int key){
        char[] fileChar = file.toCharArray();
		for(int i = 0;i<fileChar.length; i++){
			int code = (int)fileChar[i];
            if(code>=32 && code<=126)
            {
                if(code+key<=126)
                    fileChar[i] = (char)(code+key);
                else
                    fileChar[i] = (char)(code+key-94);
            }
		}
		String encrypted = new String(fileChar);
		return encrypted;
	}

	public String decrypt(String file, int key){
        char[] fileChar = file.toCharArray();
		for(int i = 0;i<fileChar.length; i++){
			int code = (int)fileChar[i];
            if(code>32 && code<126)
            {
                if(code-key>=32)
                    fileChar[i] = (char)(code-key);
                else
                    fileChar[i] = (char)(code-key+94);
            }
		}
		String decrypted = new String(fileChar);
		return decrypted;
	}


}