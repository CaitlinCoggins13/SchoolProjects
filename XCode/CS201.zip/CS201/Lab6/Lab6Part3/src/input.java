import java.io.*;

public class input{
	private File file;
	private BufferedReader reader;
	private FileWriter writer;
    
	public input(File file){
		readFile(file);
	}

	public void readFile( File file){
		// attempt to create the fileReader
		try
		{
			// first creates a FileReader of the specified file
			// may throw exception
			FileReader fileReader = new FileReader(file);

			// if control gets here, no exception was thrown

			// wrap fileReader in BufferedReader for
			// line reading capability
			reader = new BufferedReader(fileReader);

		}
		// catch the exception, if thrown
		catch (FileNotFoundException fnfe)
		{
			// file was not found
			// print error
			fnfe.printStackTrace();
		}
	}

	public String parseFile(){
		//hold the next line
		String currentLine = getNextLine();

		//body is empty at first
		String bodyText = "";

		// while there is a line
		while (currentLine != null)
		{
			// update body
			bodyText = bodyText + currentLine + "\n";

			// get next line
			currentLine = getNextLine();
		}

		return bodyText;
	}
	
	public String getNextLine()
	{
		// try to parse each line of file
		try
		{
			// try to read a line
			// if this is successful, return it
			return reader.readLine();
		}
		// catch exception, if one is thrown
		catch (IOException e)
		{
			// if there was an exception,
			// return the empty string
			return null;
		}
	}

	public void writeFile(String writeBody, File file){

		//try catch for attempting to access write file
		try {
			writer = new FileWriter(file);
			// catch IO error
			
			writer.write(writeBody);
			
			// ensure all data has been written
			writer.flush();

			// close file
			writer.close();
		}
		// catch error, if thrown
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}