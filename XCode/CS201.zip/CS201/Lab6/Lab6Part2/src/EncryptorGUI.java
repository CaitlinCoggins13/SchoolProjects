// EncryptorGUI.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

// swing
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JFileChooser;

// io
import java.io.*;

/**
 * EncryptorGUI creates all the GUI elements and listens for clicks on any buttons.
 * Actions are performed based on which button was clicked.
 **/
public class EncryptorGUI extends JPanel implements ActionListener
{
    // holds the current key
    private int key;
    
    // holds the input text
    private String inputText;
    
    // holds the output text
    private String outputText;
    
    // the input text area
	private JTextArea inputTextDisp;
    
    // the output text area
    private JTextArea encryptTextDisp;
    
    // the import text button
    private JButton openButton;
    
    // the export text button
    private JButton saveButton;
    
    // the encryption button
    private JButton encryptButton;
    
    // the decryption button
    private JButton decryptButton;
    
    // the input field for the encryption key
    private JTextField keyInputField;
    
    // instance of input
    // private input inputInfo;
    
    // instance of encryption
    // private Encryption encryptAndDecrypt;
    
    // holds the current file
    private File file;
    
    /**
     * Constructor.
     * Calls super and initialises the instance of encryption.
     * Adds the GUI elements.
     **/
    public EncryptorGUI()
    {
        // calls super
        super(new BorderLayout());
        
        // creates an encryption instance
        encryptAndDecrypt = new Encryption();
        
        // adds the GUI elements
        add(readAndWriteButtons(), BorderLayout.NORTH);
        add(textSpace(), BorderLayout.CENTER);
        add(encryptDecryptAndKey(), BorderLayout.SOUTH);
    }

    /**
     * Creates the buttons for impoting and exporting text and the labels for the text areas.
     * @return topThings things displayed and the top of the GUI
     **/
    public JPanel readAndWriteButtons()
    {
        JPanel topThings = new JPanel(new BorderLayout());
        
        // holds the buttons
        JPanel topButtons = new JPanel(new GridLayout(1, 2));
        
        // create import button and add ActionListener
        openButton = new JButton( "Open");
        openButton.addActionListener(this);
        topButtons.add(openButton);
        
        // create export button and add ActionListener
        saveButton = new JButton( "Save");
        saveButton.addActionListener(this);
        topButtons.add(saveButton);
        
        topThings.add(topButtons, BorderLayout.NORTH);
        
        // holds the labels
        JPanel areaLabels = new JPanel(new GridLayout(1, 2));
        
        // create input label
        JLabel input = new JLabel("Input");
        areaLabels.add(input);
        
        // create output label
        JLabel output = new JLabel("Output");
        areaLabels.add(output);
        
        topThings.add(areaLabels, BorderLayout.SOUTH);
        
        return(topThings);
    }
    
    /**
     * Creates the text areas to display inputted and outputted text.
     * @return testAreas the text areas for the display
     **/
    public JPanel textSpace()
    {
        JPanel testAreas = new JPanel(new BorderLayout());
        
        JPanel displayText = new JPanel(new GridLayout(1, 2));
        
        // create and add input text area
        inputTextDisp = new JTextArea( "" );
        // adds line wrapping
        inputTextDisp.setLineWrap(true);
        // adds word wrapping
        inputTextDisp.setWrapStyleWord(true);
        displayText.add( inputTextDisp );
        
        // create and add output text area
        encryptTextDisp = new JTextArea( "" );
        encryptTextDisp.setBackground(Color.LIGHT_GRAY);
        // adds line wrapping
        encryptTextDisp.setLineWrap(true);
        // adds word wrapping
        encryptTextDisp.setWrapStyleWord(true);
        displayText.add( encryptTextDisp );
        
        testAreas.add(displayText, BorderLayout.CENTER);
        
        return(testAreas);
    }
    
    /**
     * Created the area for users to enter a key and buttons for encryption and decryption
     * @return bottomDisplay the part of the display that appears at the bottom of the GUI
     **/
    public JPanel encryptDecryptAndKey()
    {
        JPanel bottomDisplay = new JPanel(new BorderLayout());
        
        // create panel to hold the text fiels and label
        JPanel inputPanel = new JPanel();
            
        // create and add label
        inputPanel.add( new JLabel( "Input a key: " ) );
            
        // create input textfield
        keyInputField = new JTextField( 15 );
            
        // add it
        inputPanel.add( keyInputField );

        
        bottomDisplay.add(inputPanel, BorderLayout.NORTH);
        
        JPanel bottomButtons = new JPanel(new GridLayout(1, 2));
        
        // create encryptor button and add ActionListener
        encryptButton = new JButton( "Encrypt");
        encryptButton.addActionListener(this);
        bottomButtons.add(encryptButton);
        
        // create decryptor button and add ActionListener
        decryptButton = new JButton( "Decrypt");
        decryptButton.addActionListener(this);
        bottomButtons.add(decryptButton);
        
        // add the buttons to the display
        bottomDisplay.add(bottomButtons, BorderLayout.SOUTH);
        
        return(bottomDisplay);
    }
    
    /**
     * Chooses a file from the user's computer.
     **/
    public void choseFile()
    {
        
        // create new JFileChooser
        JFileChooser chooser = new JFileChooser();
        
        //assign the choice and check for submission
        int userChoice = chooser.showOpenDialog(this);
        if (userChoice == JFileChooser.APPROVE_OPTION){
            file = chooser.getSelectedFile();
        }
        
    }
    
    /**
     * Performs different actions based on which button was clicked.
     * @param e ActionEvent object
     **/
    public void actionPerformed( ActionEvent e )
    {
        // gets the button that was clicked
        JButton buttonPressed = (JButton)e.getSource();
        
        // user wants to import text
        if(buttonPressed == openButton)
        {
            // choose the file to import from
            choseFile();
            // read the file
            // inputInfo = new input(file);
            // parse the text
            // inputText = inputInfo.parseFile();
            // show the text
            // inputTextDisp.setText(inputText);
        }
        
        // user wants to export text
        else if(buttonPressed == saveButton)
        {
            // choose the file to export to
            choseFile();
            // export the text
            // inputInfo.writeFile(outputText, file);
        }
        
        // user wants to encrypt text
        else if(buttonPressed == encryptButton)
        {
            // get the key
            key = Integer.parseInt(keyInputField.getText());
            // encrypt the text
            // outputText = encryptAndDecrypt.encrypt(inputText, key);
            // decrypt the text
            // encryptTextDisp.setText(outputText);
        }
        
        // user wants to decrypt text
        else if(buttonPressed == decryptButton)
        {
            // get the key
            key = Integer.parseInt(keyInputField.getText());
            // decrypt the text
            // outputText = encryptAndDecrypt.decrypt(inputText, key);
            // show the text
            // encryptTextDisp.setText(outputText);
        }
        
        // shouldn't happen
        else
            System.out.println("Why are we here");
    }
}