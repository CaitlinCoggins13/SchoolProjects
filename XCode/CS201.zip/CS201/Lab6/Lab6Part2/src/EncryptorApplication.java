// EncryptorApplication.java
// Caitlin Coggins

import javax.swing.JFrame;

/**
 * EncryptorApplication starts the program.
 **/
public class EncryptorApplication
{
	public static void main(String[] args)
    {
		JFrame frame = new JFrame("Text Panel");
		frame.getContentPane().add(new EncryptorGUI());
		frame.setSize(500, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
