// EncryptorGUI.java
// Caitlin Coggins

// awt
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

// io
import java.io.*;

/**
 * EncryptorGUI creates all the GUI elements and listens for clicks on any buttons.
 * Actions are performed based on which button was clicked.
 **/
public class EncryptionGUI extends JPanel implements ActionListener
{
    // holds the current key
    private int key;
    
    // holds the input text
    private String inputText;
    
    // holds the output text
    private String outputText;
    
    // the input text area
	private JTextArea inputTextDisp;
    
    // the output text area
    private JTextArea encryptTextDisp;
    
    // the import text button
    private JButton openButton;
    
    // the export text button
    private JButton saveButton;
    
    // the encryption button
    private JButton encryptButton;
    
    // the decryption button
    private JButton decryptButton;
    
    // the input field for the encryption key
    private JTextField keyInputField;
    
    // instance of input
    private Input inputInfo;
    
    // instance of encryption
    private Encryption encryptAndDecrypt;
    
    // holds the current file
    private File file;
    
    /**
     * Constructor.
     * Calls super and initializes the instance of encryption.
     * Adds the GUI elements.
     **/
    public EncryptionGUI()
    {
 
    }

    /**
     * Creates the buttons for importing and exporting text and the labels for the text areas.
     * @return topThings things displayed and the top of the GUI
     **/
    public JPanel readAndWriteButtons()
    {
        JPanel topThings = new JPanel();
        
        return(topThings);
    }
    
    /**
     * Creates the text areas to display inputted and outputted text.
     * @return testAreas the text areas for the display
     **/
    public JPanel textSpace()
    {
        JPanel testAreas = new JPanel();
        
        return(testAreas);
    }
    
    /**
     * Created the area for users to enter a key and buttons for encryption and decryption
     * @return bottomDisplay the part of the display that appears at the bottom of the GUI
     **/
    public JPanel encryptDecryptAndKey()
    {
        JPanel bottomDisplay = new JPanel();
        return(bottomDisplay);
    }
    
    /**
     * Chooses a file from the user's computer.
     **/
    public void choseFile()
    {
  
    }

    /*
     * Does an action based on the button clicked.
     * @param e ActionEvent object
     */
    public void actionPerformed( ActionEvent e )
    {
    }
}