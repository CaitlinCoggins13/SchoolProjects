import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * Input takes in a file and reads and parses the text.
 * It can also write to a file.
 */
public class Input{
	
	/* Reads the file chosen. */
	private BufferedReader reader;
	/* Writes to the file chosen. */
	private FileWriter writer;
    
	/*
	 * Constructor.  Sends the file to be read.
	 * @param file the file that will be read
	 */
	public Input(File file)
	{
		
	}
	
	/*
	 * Creates a FileReader if the file exists.
	 * @param file the file being read
	 */
	public void readFile( File file)
	{

	}

	/*
	 * Gets the chosen file's text.
	 * @return bodyText the file's text
	 */
	public String parseFile()
	{
		String bodyText = "";
		return bodyText;
	}
	
	/*
	 * Gets the next line of text in the document.
	 * @return readLine the next line of text
	 */
	public String getNextLine()
	{
		String readLine = "";
		return readLine;
	}

	/*
	 * Writes the given text to the file chosen.
	 * @param writeBody the text being written
	 * @param file the file being written to
	 */
	public void writeFile(String writeBody, File file)
	{

	}
}