import javax.swing.JFrame;

/*
 * EncryptionApplication starts the program.
 */
public class EncryptionApplication
{
	/*
	 * Main.  Creates a JFrame and begins the program.
	 */
	public static void main(String[] args)
    {
		
	}
}
