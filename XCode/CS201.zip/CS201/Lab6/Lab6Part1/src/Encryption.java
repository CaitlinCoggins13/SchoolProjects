/*
 * Encryption both encrypts and decrypts a string provided.
 */
public class Encryption
{
	/* the String to be encrypted or decrypted */
	private String file;
	/* the key used to encrypt or decrypt */
	private int key;
	
	/*
	 * Constructor.
	 */
	public Encryption()
	{
		
	}
	
	/*
	 * Encrypts the given text with the given key.
	 * @param text the text to be encrypted
	 * @param key the key used to encrypt
	 */
	public String encrypt(String text, int key)
	{
        String encrypted = ".";
		return encrypted;
	}

	/*
	 * Decrypts the given text with the given key.
	 * @param text the text to be decrypted
	 * @param key the key used to decrypt
	 */
	public String decrypt(String text, int key)
	{
		String decrypted = ".";
		return decrypted;
	}
}