// IceCreamLine.java

public class IceCreamLine
{
    public IceCreamLine()
    {
        
    }
}