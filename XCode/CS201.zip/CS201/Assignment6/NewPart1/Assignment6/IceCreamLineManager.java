import javax.swing.BoxLayout;

public class IceCreamLineManager
{
    public IceCreamLineManager()
    {
        
    }
}