// Queue<T>.java
// Caitlin Coggins

public class QueueLL<T> implements Queue<T>
{
    private LinkedList<T> queueList;
    
    public QueueLL<T>()
    {
        queueList = new LinkedList<T>;
    }
    
    public T peek()
    {
        return stackList.getFirst();
    }
        
    public void dequeue()
    {
        queueList.deleteFirst();
    }
        
    public void enqueue(T data)
    {
        queueList.insertLast(data);
    }
    
    public boolean empty()
    {
        return queueList.isEmpty();
    }
}