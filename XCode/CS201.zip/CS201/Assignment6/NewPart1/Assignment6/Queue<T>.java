// Queue<T>.java
// Caitlin Coggins

public interface Queue<T>
{
    public T peek();
        
    public void dequeue();
        
    public void enqueue(T data);
    
    public boolean empty();
}