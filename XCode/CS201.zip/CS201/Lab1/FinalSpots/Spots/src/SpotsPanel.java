//SpotsPanel.java
//Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * SpotsPanel draws and ice cream cone, takes an ice cream flavor as input, then 
 * uses it to draw a scoop of ice cream of that flavor.
 **/

public class SpotsPanel extends JPanel implements ActionListener
{
    // instance variables
    private JTextField nameInputField;
    private SpotsDisplay spotsDisplay;
    
    /**
     * Call super to construct new panel.
     * Add input panel, ice cream display, and ice cream button.
     **/
    public SpotsPanel()
    {
        super( new BorderLayout() );
        
        add(createInputPanel(), BorderLayout.NORTH );
        
        add(createSpotsDisplay(), BorderLayout.CENTER );
        
        add(createSpotsButton(), BorderLayout.SOUTH );
    }

    /**
     * Create and return input panel.
     **/
    public JPanel createInputPanel()
    {
        JPanel inputPanel = new JPanel();
        
        // create and add label
        inputPanel.add( new JLabel( "Your name" ) );

        // create input textfield
        nameInputField = new JTextField( 10 );

        // add it
        inputPanel.add( nameInputField );

        // return created panel
        return inputPanel;
    }

    /**
     * Create and return spots display.
     **/
    public SpotsDisplay createSpotsDisplay()
    {
        spotsDisplay = new SpotsDisplay();
        return spotsDisplay;
    }

    /**
     * Create and return spots button.
    **/
    public JButton createSpotsButton()
    {
        // create a button
        JButton spotsButton = new JButton( "Time to see some spots!" );

        // add this as the action listener for button's action (click)
        spotsButton.addActionListener( this );

        // return the button
        return spotsButton;
    }
    
    /**
	 * Display spots.
	 **/
	public void seeSpots()
	{
		// get the person's name
		String name = nameInputField.getText();
		
		// set the number of spots to see
		spotsDisplay.setNumberOfSpots( name.length() );
		
		// tell graphics to update
		spotsDisplay.repaint();
	}
	
	/**
	 * Special method required by implementing ActionListener
	 * (function signature cannot be changed)
	 * Invoked when an action is performed on the spotsButton, since this
	 * was added as an ActionListener.
	 **/
	public void actionPerformed( ActionEvent e )
	{
		// this is where you put the code you want
		// executed when the button is pressed
		// here, we call a method to update the display
		seeSpots();
	}


}