// SpotsApplication.java
// Audrey St. John

/** 
 * Main application to show a SpotsFrame 
 **/
public class SpotsApplication
{
	/**
	 * main method starts the program
	 **/
	public static void main( String[] args )
	{
		// create a new SpotsFrame
		new SpotsFrame();
	}
}