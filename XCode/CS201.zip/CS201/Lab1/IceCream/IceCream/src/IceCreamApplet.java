// IceCreamApplet.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * IceCreamApplet takes one of a list of ice cream flavors as input, then uses it to draw an ice cream cone of that flavor.
 * @author Caitlin Coggins
 **/
public class IceCreamApplet extends JApplet
{
	
	/**
	 * Constructor, invoked for a new instance
	 **/
	public IceCreamApplet()
	{
		// call super constructor
		super();
	}
	
	/**
	 * special method invoked when applet is created; looks for parameter type with value menu to show a menu.
	 **/
	public void start()
	{
		// if creating a menu
        
		System.out.println( getParameter( "type" ) );
		if ( (getParameter( "type" ) != null) && (getParameter( "type" ).equals( "menu" )) )
			// create an IceCreamPanel and add it
			add( new MenuIceCreamPanel() );
		else
			// otherwise, create an IceCreamPanel and add it
			add( new IceCreamPanel() );
	}

	
}