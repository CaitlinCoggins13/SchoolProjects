// IceCreamApplication.java
// Caitlin Coggins

/**
 * Main application to show an IceCreamFrame
 **/

import javax.swing.JFrame;

public class IceCreamApplication
{
	/**
	 * main method starts the program
	 **/
	public static void main( String[] args )
	{
		// create a new JFrame to hold IceCreamPanel
		JFrame icecreamFrame = new JFrame();
        
		// set size
		icecreamFrame.setSize( 600, 400 );
        
        // no text entered: default to IceCreamPanel
        if(args.length == 0)
            
            // create an IceCreamPanel and add it
            icecreamFrame.add( new IceCreamPanel() );
        
        // else text entered: either incorrect usage or selection of MenuIceCreamPanel
        else
        {
            // if incorrect usage, print instructions
            if(args[0].equals("menu"))
            {
               // creates and adds MenuIceCreamPanel
               icecreamFrame.add( new MenuIceCreamPanel() );
            }
            
            // else, create a MenuIceCreamPanel and add it
            else
            {
                printUsage();
            }
            
        }
        
		// exit normally on closing the window
		icecreamFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        
		// show frame
		icecreamFrame.setVisible( true );
        
	}
    
    /**
     * When the user does not input menu, these instructions are printed.
     **/
    public static void printUsage()
    {
        System.out.println( "USAGE: java IceCreamApplication <panelType>" );
        System.out.println( "   first <panelType> optional argument should be: menu" );
        System.out.println( "   When no arguments are passed, defaults to an IceCreamPanel.");
    }
}