// MenuIceCreamPanel.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.GridLayout;

// swing
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MenuIceCreamPanel extends IceCreamPanel
{
    /**
     * Menu for the ice cream shop.
     **/
    public static final String menu = "<html><b><u>Flavors</u></b><br/>vanilla<br/>strawberry<br/>chocolate<br/>mint<br/></html>";
    
    /**
	 * constructor
	 **/
	public MenuIceCreamPanel()
	{
		// call the superclass' constructor
		super();
	}
    
    /**
	 * Override to display menu.
	 **/
	public JPanel createInputPanel()
	{
		// create JPanel with GridLayout -- 2 rows, 1 column
		JPanel inputPanel = new JPanel( new GridLayout( 2, 1 ) );
        
		// use superclass' method to create smaller panel and add it
		inputPanel.add( super.createInputPanel() );
        
		// add the menu
		inputPanel.add( new JLabel( menu ) );
        
		// return created panel
		return inputPanel;
	}
    
    

}