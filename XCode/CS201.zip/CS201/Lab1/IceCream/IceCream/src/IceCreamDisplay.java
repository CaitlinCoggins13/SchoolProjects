// IceCreamDisplay.java
// Caitlin Coggins

// awt
import java.awt.Color;
import java.awt.Graphics;

// swing
import javax.swing.JComponent;

/**
 * IceCreamDisplay is a GUI element that draws an ice cream cone and scoops of ice cream.
 * @author Caitlin Coggins
 **/


public class IceCreamDisplay extends JComponent
{
	// constants
	public static final Color[] PAINT_COLORS = {Color.WHITE, new Color(150, 100, 80), Color.PINK, Color.GREEN};
    
    //instance properties
    private int chosen = -1;
    
	/**
	 * constructor
	 **/
	public IceCreamDisplay()
	{
		// call superclass' constructor
		super();
		
		// initialize instance properties
		this.chosen = chosen;
	}
	
	/**
	 * Given a string, the value of chosen is set based on the content.
	 * Valid parameter values: "vanilla", "chocolate", "strawberry", "mint"
	 * If invalid paramter is passed, chosen is set to -1
	 **/
	public void setColorOfScoop( String flavor )
	{
		// check for valid value and set value of variable chosen
		if ( flavor.equals ("vanilla") )
			chosen = 0;
        else if ( flavor.equals ("chocolate") )
            chosen = 1;
        else if ( flavor.equals ("strawberry") )
            chosen = 2;
        else if ( flavor.equals ("mint") )
            chosen = 3;
        else
            chosen = -1;
        
	}
    
	/**
     * Override paint method
     **/
    public void paint( Graphics g )
	{
        drawIceCream( g );
	}
    
    /**
	 * Sets the color of cone and draws cone
     * If chosen is not equal to -1 (invalid text entered), the color of the ice cream 
     * scoop is set and drawn.
	 **/
    public void drawIceCream ( Graphics g )
    {
        // color of cone is set
        g.setColor( Color.YELLOW );
        
        // arrays of x and y coordinates for each point of the polygon
        int[] x = {300, 280, 320};
        int[] y = {250, 180, 180};
        
        // cone is drawn
        g.fillPolygon(x, y, 3);
        //docs.oracle.com referenced for polygon drawing
        
        if( chosen != -1 )
        {
            // color of scoop is set
            g.setColor( PAINT_COLORS[chosen] );
        
            // fill oval (upper left x, upper left y, width, height)
            g.fillOval( 272, 140, 55, 55 );
        }
    }

}