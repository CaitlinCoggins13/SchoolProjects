//IceCreamPanel.java
//Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


// swing
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * IceCreamPanel takes an ice cream flavor as input, then uses it to draw a scoop of ice cream of that flavor.
 **/

public class IceCreamPanel extends JPanel implements ActionListener
{
    // instance variables
    private JTextField nameInputField;
    private IceCreamDisplay icecreamDisplay;
    
    /**
     * Call super to construct new panel.
     * Add input panel, ice cream display, and ice cream button.
     **/
    public IceCreamPanel()
    {
        super( new BorderLayout() );
        
        add(createInputPanel(), BorderLayout.NORTH );
        
        add(createIceCreamDisplay(), BorderLayout.CENTER );
        
        add(createIceCreamButton(), BorderLayout.SOUTH );
    }
    
    /**
     * Create and return input panel.
     **/
    public JPanel createInputPanel()
    {
        JPanel inputPanel = new JPanel();
        
        // create and add label
        inputPanel.add( new JLabel( "Flavor" ) );
        
        // create input textfield
        nameInputField = new JTextField( 10 );
        
        // add it
        inputPanel.add( nameInputField );
        
        // return created panel
        return inputPanel;
    }
    
    /**
     * Create and return ice cream display.
     **/
    public IceCreamDisplay createIceCreamDisplay()
    {
        icecreamDisplay = new IceCreamDisplay();
        return icecreamDisplay;
    }
    
    /**
     * Create and return ice cream button.
     **/
    public JButton createIceCreamButton()
    {
        // create a button
        JButton icecreamButton = new JButton( "Time for ice cream!" );
        
        // add this as the action listener for button's action (click)
        icecreamButton.addActionListener( this );
        
        // return the button
        return icecreamButton;
    }
    
    /**
	 * Display ice cream scoop.
	 **/
	public void seeScoop()
	{
		// get the ice cream flavor
		String flavor = nameInputField.getText();
        flavor = flavor.toLowerCase();  //http://msdn.microsoft.com/en-US/library/aa989676(v=vs.80).aspx referenced
		
		// set the color of the ice cream scoop to see
		icecreamDisplay.setColorOfScoop( flavor );
		
		// tell graphics to update
		icecreamDisplay.repaint();
	}
	
	/**
	 * Special method required by implementing ActionListener
	 * (function signature cannot be changed)
	 * Invoked when an action is performed on the icecreamButton, since this
	 * was added as an ActionListener.
	 **/
	public void actionPerformed( ActionEvent e )
	{
		// this is where you put the code you want
		// executed when the button is pressed
		// here, we call a method to update the display
		seeScoop();
	}
    
    
}