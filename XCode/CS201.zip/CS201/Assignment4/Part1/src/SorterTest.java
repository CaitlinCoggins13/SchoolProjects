// SorterTester.java
// Caitlin Coggins

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

// lang
import java.lang.Math.*;

/**
 * SorterTest tests the methods for insertion, selection, bubble, and merge sort.
 * @author caitlincoggins
 */
public class SorterTest
{
    /** default number of Comparables to test on **/
    public static int NUM_COMPARABLES = 20;
    
    /** testing array **/
    private Comparable[] comparables;
    
    /**
     * Initializes the testing array.
     */
    @Before
    public void initTesterArray()
    {
        comparables = createTesterArray( NUM_COMPARABLES );
    }
    
    /**
     * Create array with random Integers between 0 and 30.
     **/
    public static Comparable[] createTesterArray( int numComparables )
    {
        // array for randomized values in order
        Comparable<Integer>[] newComparables = new Comparable[numComparables];
        
        for ( int i = 0; i < newComparables.length; i++ )
        {
        	// generate value between 0 and 30
            Integer testLetter = ((int) Math.random()*31);
            // put in current number
            newComparables[i] = testLetter;
        }
        
        return newComparables;
    }
    
    /**
     * Tests the insertion sort method.
     */
    @Test
    public void testInsertionSort()
    {
    	boolean run = true;
    	
    	
    	Comparable[] sorted = Sorter.insertionSort(comparables);
    	
    	// Run through array, make sure each value is in order
    	for(int i = 0; i<sorted.length-1; ++i)
    	{	
    		if(sorted[i].compareTo(sorted[i+1]) == 1)
    		{
    			run = false;
    			break;
    		}
    	}
    
        // check searching for 26
        assertEquals("Searching for no greater numbers to the left of lesser numbers should give true", 
                     true, // correct answer
                     run);
    }

    /**
     * Tests the selection sort method.
     */
	@Test
    public void testSelectionSort()
    {
		boolean run = true;
    	
		// Run through array, make sure each value is in order
    	Comparable[] sorted = Sorter.selectionSort(comparables);
    	for(int i = 0; i<sorted.length-1; ++i)
    	{
    		if(sorted[i].compareTo(sorted[i+1]) == 1)
    		{
    			run = false;
    			break;
    		}
    	}
    
        // check searching for 26
        assertEquals("Searching for no greater numbers to the left of lesser numbers should give true",
                     true, // correct answer
                     run);
    }
    
	/**
     * Tests the bubble sort method.
     */
    @Test
    public void testBubbleSort()
    {
    	
    	boolean run = true;
    	
    	// Run through array, make sure each value is in order
    	Comparable[] sorted = Sorter.bubbleSort(comparables);
    	for(int i = 0; i<sorted.length-1; ++i)
    	{
    		if(sorted[i].compareTo(sorted[i+1]) == 1)
    		{
    			run = false;
    			break;
    		}
    	}
        // check searching for 26
        assertEquals("Searching for no greater numbers to the left of lesser numbers should give true",
                     true, // correct answer
                     run);
    }
    
    /**
     * Tests the merge sort method.
     */
    @Test
    public void testMergeSort()
    {
    	boolean run = true;
    	
    	// Run through array, make sure each value is in order
    	Comparable[] sorted = Sorter.mergeSort(comparables);
    	for(int i = 0; i<sorted.length-1; ++i)
    	{
    		if(sorted[i].compareTo(sorted[i+1]) == 1)
    		{
    			run = false;
    			break;
    		}
    	}
    
        // check searching for 26
        assertEquals("Searching for no greater numbers to the left of lesser numbers should give true",
                     true, // correct answer
                     run);
    }
}
    