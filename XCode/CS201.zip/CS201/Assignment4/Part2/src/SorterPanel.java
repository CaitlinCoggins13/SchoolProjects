// SorterPanel.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Graphics;
import java.awt.Color;

// swing
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;

// lang
import java.lang.Math.*;

/*
 * SorterPanel creates the GUI display, generates random arrays, and sorts an array when
 * certain buttons are clicked.
 */
public class SorterPanel extends JPanel implements ActionListener
{
	/** The number of elements to be placed in the array. **/
	public static int NUM_COMPARABLES = 20;
    
	/** Holds numbers to be sorted. **/
    private Integer[] sortEntireArray;
    
    /** Button pressed to generate a new array. **/
    private JButton createArray;
    
    /** Button pressed to sort the array with insertion sort. **/
    private JButton sortInsertion;
    
    /** Button pressed to sort the array with selection sort. **/
    private JButton sortSelection;
    
    /** Button pressed to sort the array with bubble sort. **/
    private JButton sortBubble;
    
    /** Button pressed to sort the array with merge sort. **/
    private JButton sortMerge;
    
    /*
     * Constructor.
     * Initializes the array that holds the values being sorted.
     * Adds all the GUI display elements.
     */
    public SorterPanel()
    {
    	// call super
        super( new BorderLayout());
        
        // initialize the array where the values are kept
        sortEntireArray = new Integer[NUM_COMPARABLES];
        
        // add buttons and the panel where the bars are drawn
        add(menuBar(), BorderLayout.NORTH);

        add(new SorterPaint(sortEntireArray), BorderLayout.CENTER);

        add(buttons(), BorderLayout.SOUTH);
    }
    
    /**
     * Creates the button used to pick a sorting method and adds ActionListeners.
     * @return sortOptions the JPanel with sorting buttons in it
     */
    public JPanel menuBar()
    {
        JPanel sortOptions = new JPanel(new GridLayout(2, 2));
        
        // insertion sort
        sortInsertion = new JButton("Insertion Sort");
        sortInsertion.addActionListener(this);
        sortOptions.add(sortInsertion);
        
        // selection sort
        sortSelection = new JButton("Selection Sort");
        sortSelection.addActionListener(this);
        sortOptions.add(sortSelection);
        
        // bubble sort
        sortBubble = new JButton("Bubble Sort");
        sortBubble.addActionListener(this);
        sortOptions.add(sortBubble);
        
        // merge sort
        sortMerge = new JButton("Merge Sort");
        sortMerge.addActionListener(this);
        sortOptions.add(sortMerge);
        
        return sortOptions;
    }
    
    /**
     * Creates a button to generate new arrays.
     * @return buttonPanel the panel containing the button to generate new arrays
     */
    public JPanel buttons()
    {
        JPanel buttonPanel = new JPanel();
        
        // generate new array button
        createArray = new JButton("Get a new array");
        createArray.addActionListener(this);
        buttonPanel.add(createArray);

        return buttonPanel;
    }

    /**
     * Creates a random array on numbers between 0 and 30.
     */
    public void createTesterArray()
    {  
        for ( int i = 0; i < this.sortEntireArray.length; ++i )
        {
        	// generate a random number from 0 to 30
            Integer testNum = ((int) (Math.random()*31));
            
            // put in current odd number
            this.sortEntireArray[i] = testNum;
        }
    }
       
    /**
     * Performs different actions, depending on which button was clicked.
     * @param e ActionEvent object
     */
    public void actionPerformed( ActionEvent e )
    {
    	// get source
    	JButton chosen = (JButton)e.getSource();
    	
    	// prevents NullPointerException
    	if(sortEntireArray != null)
    	{
    		// use insertion sort
    		if(chosen == sortInsertion)
    		{
    			// sorts the array, then repaint
                // casting works here because what's being returned is an altered version of the instance sent in
    			sortEntireArray = (Integer[]) Sorter.insertionSort(sortEntireArray);
    			repaint();
    		}
             
    		// use selection sort
    		else if(chosen == sortSelection)
    		{
    			// sorts the array, then repaint
    			sortEntireArray = (Integer[]) (Sorter.selectionSort(sortEntireArray));
    			repaint();
    		}
            
    		// use bubble sort
    		else if(chosen == sortBubble)
    		{
    			// sorts the array, then repaint
    			sortEntireArray =  (Integer[]) Sorter.bubbleSort(sortEntireArray);
    			repaint();
    		}
             
    		// use merge sort
    		else if(chosen == sortMerge)
    		{
    			// sorts the array 
    			Comparable[] help = Sorter.mergeSort(sortEntireArray);
    			
    			// convert Comparable to Integer
    			Sorter.convert(help, sortEntireArray);
                
    			// repaint
    			repaint();
    		}
    	}
    	
        // Generates a new array      
        if(chosen == createArray)
        {
            createTesterArray();
            repaint();
        }
            
    }
                                  
}