// NumberscopeEngine.java
// Caitlin Coggins

/**
 * NumberscopeEngine
 **/
public class NumberscopeEngine implements HoroscopeEngine
{
    // constant
    private final String[] message = { "Watch out for stacks of ", " notebooks and groups of ", " girls singing in unison, or you'll trip ", " times tomorrow." };
    
    //instance
    String horoscope;
    
    /**
     * Constructor
     **/
    public NumberscopeEngine()
    {
        horoscope="";
    }
    
    /**
     * Creates the horoscope message and returns it
     **/
    public String getHoroscope()
    {
        horoscope = message[0] + generateNumbers() + message[1] + generateNumbers() + message[2] + generateNumbers() + message[3] ;
        
        return horoscope;
    }
    
    /**
     * Generates a random number and returns it.
     **/
    public int generateNumbers()
    {
        // generates a random number
        int randomNum = (int)((Math.random()*18)+2);

        return randomNum;
    }

}