// MohoscopeEngine.java
// Caitlin Coggins

/**
 * MohoscopeEngine creates a horoscope message with randomized places in the message.
 **/

public class MohoscopeEngine implements HoroscopeEngine
{
    // constants
    private final String[] message = { "Run quickly from ", " to " , " today, or you will miss the note about your next class being moved from " , " to " , "!" };
    private final String[] places = { "Pratt" , "Reese" , "Skinner Green", "Shattuck" , "Clapp" };
    
    // instance
    String horoscope;
    
    int lastNum=5;
    
    /**
     * Constructor
     **/
    public MohoscopeEngine()
    {
       horoscope = "";
    }
    
    /**
     * Creates the horoscope message and returns it
     **/
    public String getHoroscope()
    {
        horoscope = message[0] + pickPlace() + message[1] + pickPlace() + message[2] + pickPlace() + message[3] + pickPlace() + message[4] ;
        
        return horoscope;
    }
    
    /**
     * Makes sure that the same place isn't picked two times in a row
     **/
    public String pickPlace()
    {
        String place;
        
        // retrieves a random number inside the bounds of the places String array
        int randomNum = (int)(Math.random()*4);

        // changes the value of the random number if it was the same as the last random number
        if ( lastNum == randomNum )
        {
            // if adding one would call an out-of-bounds cell, subtract one
            if( randomNum == 4 )
                randomNum-=1;
            
            //else add one
            else
                randomNum+=1;
        }
        
        // lastNum is set to check in the next randomization
        lastNum=randomNum;
        
        // the place is retrieved from the places array
        place=places[randomNum];
        
        //the place is retuned
        return place;
    }

}

