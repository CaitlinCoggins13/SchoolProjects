// HoroscopeApplication.java
// Caitlin Coggins

/**
 * HoroscopeApplication
 **/

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.GridLayout;

public class HoroscopeApplication
{
	/**
	 * main method starts the program
	 **/
    
    // constants
    public static NumberscopeEngine myNumberscope = new NumberscopeEngine();
    public static MohoscopeEngine myMohoscope = new MohoscopeEngine();
    public static MadoscopeEngine myMadoscope = new MadoscopeEngine();
    
	public static void main( String[] args )
	{
		// create a new JFrame to hold IceCreamPanel
		JFrame horoscopeFrame = new JFrame();
        
		// set size
		horoscopeFrame.setSize( 600, 400 );
        
        // create panel for each horoscope panel
        JPanel horoscopePanel = new JPanel( new GridLayout(1, 3));
        
        //add a HoroscopeDisplay for each kind of horoscope
        horoscopePanel.add( new HoroscopeDisplay(myNumberscope, "numberscope") );

        horoscopePanel.add( new HoroscopeDisplay(myMohoscope, "mohoscope") );

        horoscopePanel.add( new HoroscopeDisplay(myMadoscope, "madoscope") );
        
        // adds the panel with all horoscope panels in it to horoscopeFrame
        horoscopeFrame.add( horoscopePanel );
        
		// exit normally on closing the window
		horoscopeFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        
		// show frame
		horoscopeFrame.setVisible( true );
        
	}

}

