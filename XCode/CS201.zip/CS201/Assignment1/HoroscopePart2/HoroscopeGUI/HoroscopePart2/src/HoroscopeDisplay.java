// HoroscopeDisplay.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * HoroscopeDisplay creates a panel with a button and a text area for each instance.
 **/

public class HoroscopeDisplay extends JPanel implements ActionListener
{
    // instance variables
    private HoroscopeEngine myHoroscope;
    private JTextArea myTextArea;
    private JButton myButton;
    
    /**
     * Call super to construct new panel.
     * Initializes myHoroscope.
     * Adds a text area and a button.
     **/
    public HoroscopeDisplay( HoroscopeEngine newHoroscope, String horoscopeName )
    {
        // calls super
        super( new GridLayout(2, 1) );
        
        // initializes myHoroscope
        myHoroscope = newHoroscope;
        
        String horoscopeType = horoscopeName;
        
        // adds text area
        add( createTextArea() );
        
        //adds button
        add( createButton(horoscopeType) );
    }
    
    /**
     * Empty constructor
     **/
    public HoroscopeDisplay()
    {
        
    }
    
    /**
     * Creates a read-only text area with margins and word wrapping
     **/
    public JTextArea createTextArea()
    {
        // creates text area
        myTextArea = new JTextArea();
        
        // creates margins
        myTextArea.setMargin(new Insets (50, 20, 20, 20));
        
        // makes text area read-only
        myTextArea.setEditable(false);
        
        // adds line wrapping
        myTextArea.setLineWrap(true);
        
        // adds word wrapping
        myTextArea.setWrapStyleWord(true);
        
        // returns text area
        return myTextArea;
    }
    
    /**
     * Creates a button, adds an actionlistener and returns it
     **/
    public JButton createButton(String horoscopeType)
    {
        // creates a JButton
        myButton = new JButton("Get a " +horoscopeType +"!");
        
        // adds ActionListener
        myButton.addActionListener( this );
        
        // returns JButton
        return myButton;
    }
    
    /**
	 * Special method required by implementing ActionListener
	 * (function signature cannot be changed)
	 * Invoked when an action is performed on the spotsButton, since this
	 * was added as an ActionListener.
	 **/
	public void actionPerformed( ActionEvent e )
	{
		// sets the text in the text area to show the horoscope
        myTextArea.setText(myHoroscope.getHoroscope());
	}
}
