// MadoscopeEngine.java
// Caitlin Coggins

/**
 * MadoscopeEngine randomly chooses a message, replaces the *, &, and # in the message with nouns,
 * verbs, and adjectives respectively, then returns the message.
 **/
public class MadoscopeEngine implements HoroscopeEngine
{
    // constants
    private final String[] messages = { "You are going to need to & your * on this # day.", "Watch out for a man with a * because he might & it, and seeing this might make your day more #.", "What a # day you will have when you accidentally & your *."};
    
    private final String[] nouns = { "pogo stick", "laptop", "hat", "water bottle", "pumpkin"};
    
    private final String[] verbs = { "throw", "eat", "clean", "punch", "lose"};
    
    private final String[] adjectives = { "disastrous", "joyous", "boring", "festive"};
    
    public static final String name = "Madoscope";
    
    // instance variable
    String horoscope;
    
    /**
     * constructor
     **/
    public MadoscopeEngine()
    {
        horoscope="";
    }
    
    /**
     * Chooses the message, replaces the symbols in the string with nouns, verbs, and 
     * adjectives, and returns it.
     **/
    public String getHoroscope()
    {
        // chooses message
        horoscope = chooseMessage(horoscope);
        
        //replaces symbols with nouns, verbs, and adjectives
        horoscope = replaceSymbols(horoscope);
        
        return horoscope;
    }
    
    /**
     * Randomly selects a template message and returns it.
     **/
    public String chooseMessage(String horoscope)
    {
        int randomNum = (int)(Math.random()*3);
        
        return messages[randomNum];
    }
    
    /**
     * Replaces symbols in the message template with nouns, verbs, and adjectives 
     * and returns the final message
     **/
    public String replaceSymbols(String horoscope)
    {
        // replaces verbs
        horoscope = horoscope.replace("&", getVerb());
        
        //replaces adjectives
        horoscope = horoscope.replace("#", getAdjective());
        
        //replaces nouns
        horoscope = horoscope.replace("*", getNoun());
        
        return horoscope;
    }
    
    /**
     * Chooses a random noun
     **/
    public String getNoun()
    {
        String noun;
        
        // random number inside the bounds of the noun String array generated
        int randomNum = (int)(Math.random()*5);
        
        // a noun is retrieved from the String array of nouns
        noun = nouns[randomNum];
        
        return noun;
    }
    
    /**
     * Chooses a random verb
     **/
    public String getVerb()
    {
        String verb;
        
        // random number inside the bounds of the verb String array generated
        int randomNum = (int)(Math.random()*5);
        
        // a verb is retrieved from the String array of verbs
        verb = verbs[randomNum];
        
        return verb;
    }
    
    /**
     * Chooses a random adjective
     **/
    public String getAdjective()
    {
        String adjective;
        
        // random number inside the bounds of the adjective String array generated
        int randomNum = (int)(Math.random()*4);
        
        // an adjective is retrieved from the String array of adjectives
        adjective = adjectives[randomNum];
        
        return adjective;
    }
}
