// HoroscopeApplet.java
// Caitlin Coggins

// awt
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// swing
import javax.swing.JButton;
import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * HoroscopeApplet
 * @author Caitlin Coggins
 **/
public class HoroscopeApplet extends JApplet
{
    
    public static NumberscopeEngine myNumberscope = new NumberscopeEngine();
    public static MohoscopeEngine myMohoscope = new MohoscopeEngine();
    public static MadoscopeEngine myMadoscope = new MadoscopeEngine();
    
	/**
	 * Constructor, invoked for a new instance
	 **/
	public HoroscopeApplet()
	{
		// call super constructor
		super();
	}
	
	/**
	 * special method invoked when applet is created
	 **/
	public void start()
	{
        // create panel for each horoscope panel
        JPanel horoscopePanel = new JPanel( new GridLayout(1, 3));
        
        //add a HoroscopeDisplay for each kind of horoscope
        horoscopePanel.add( new HoroscopeDisplay(myNumberscope, "numberscope") );
        
        horoscopePanel.add( new HoroscopeDisplay(myMohoscope, "mohoscope") );
        
        horoscopePanel.add( new HoroscopeDisplay(myMadoscope, "madoscope") );
        
        // adds the panel with all horoscope panels in it to scene
        add( horoscopePanel );
    }
}