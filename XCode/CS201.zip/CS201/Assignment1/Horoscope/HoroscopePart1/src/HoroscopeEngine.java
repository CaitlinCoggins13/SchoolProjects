//HoroscopeEngine.java
//Caitlin Coggins

/**
 * This interface is designed to be implemented in all other horoscope-creating classes.
 **/

public interface HoroscopeEngine
{
    /**
    * This retrieves the horoscope.
    **/
    public String getHoroscope();
}