// NumberscopeEngine.java
// Caitlin Coggins

public class NumberscopeEngine implements HoroscopeEngine
{
    String[] message = { "Watch out for stacks of ", " notebooks and groups of ", " girls singing in unison, or you'll trip ", " times tomorrow." };
    
    String horoscope;
    
    public NumberscopeEngine()
    {
        horoscope="";
    }
    
    public String getHoroscope()
    {
        createHoroscope();
        
        return horoscope;
    }
    
    public int generateNumbers()
    {
        int randomNum = (int)((Math.random()*18)+2);
        
        String stringNum = Integer.toString(randomNum);

        return randomNum;
    }
    
    public void createHoroscope()
    {
        horoscope = message[0] + generateNumbers() + message[1] + generateNumbers() + message[2] + generateNumbers() + message[3] ;
    }
}