// HoroscopeTester.java
// Caitlin Coggins

public class HoroscopeTester
{
        /**
         * Testing through main method.
         * If an argument is passed, set the temperature to that value.
         **/
    public static void main( String[] args )
    {
        HoroscopeEngine myHoroscope;
        
        // if no type of horoscope selected, default to numberscope
        if( args.length == 0)
        {
            // create a new numberscope
            myHoroscope = new NumberscopeEngine();
            
            // print theoroscope
            System.out.println( myHoroscope.getHoroscope() );
        }
        else
        {
        // if incorrect usage, display instructions
            if ( !( args[0].equals( "numberscope" ) || args[0].equals( "mohoscope" ) || args[0].equals( "madoscope") ) )
			{
				// print out usage
				printUsage();
			}
        // else, correct usage -- either numberscope or mohoscope
			else
			{
				// if it's a numberscope
				if ( args[0].equals( "numberscope" ) )
				{
					// create a new numberscope
					myHoroscope = new NumberscopeEngine();
				}
				// otherwise, mohoscope
				else if ( args[0].equals( "mohoscope"))
				{
					// create a new mohoscope
					myHoroscope = new MohoscopeEngine();
				}
                else
                    myHoroscope = new MadoscopeEngine();
                
                System.out.println( myHoroscope.getHoroscope() );
            }
        }
    }
    
    /**
     * When the user inputs an invalid horoscope type, these instructions are printed.
     **/
    public static void printUsage()
    {
        System.out.println( "USAGE: java HoroscopeTester <horoscopeType>" );
        System.out.println( "   first <horoscopeType> optional argument should be: numberscope, mohoscope or madoscope" );
        System.out.println( "   When no arguments are passed, defaults to a Numberscope.");
    }

}