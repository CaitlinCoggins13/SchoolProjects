//LinkedListNode<T>.java

public class LinkedListNode<T>
{
    private T data;
    
    private LinkedListNode<T> next;
    
    public LinkedListNode(T data)
    {
        this.setData(data);
    }
    
    /**
     * Get the data stored at this node.
     **/
    public T getData()
    {
        return data;
    }
    
    /**
     * Set the data stored at this node.
     **/
    public void setData( T data )
    {
        this.data = data;
    }
    
    /**
     * Get (pointer to) next node.
     **/
    public LinkedListNode<T> getNext()
    {
        return next;
    }
    
    /**
     * Set the next pointer to passed node.
     **/
    public void setNext( LinkedListNode<T> node )
    {
        this.next = node;
    }
    
    /**
     * Returns a String representation of this node.
     **/
    public String toString()
    {
        return (String) (data);
    }
}