import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;

public class LinkedListTest 
{

	/**Create an empty list
	Insert "a" at the head
	Insert "v" at the head
	Insert "a" at the head
	Insert "l" at the head
	Insert "o" at the head
	Insert "i" at the head
	Insert "j" after the node following the head node
	Insert "e" after the node following the head node
	Insert "v" after the node following the head node
	Insert "l" after the head node
	Delete the node after the node after the node after the node after the node after the head node.
	**/

	@Test
	public void test() 
	{
		LinkedList<String> testList = new LinkedList<String>();
		
		testList.insertFirst("a");
		testList.insertFirst("v");
		testList.insertFirst("a");
		testList.insertFirst("l");
		testList.insertFirst("o");
		testList.insertFirst("i");
		testList.insertAfter(testList.getFirstNode().getNext(), "j");
		testList.insertAfter(testList.getFirstNode().getNext(), "e");
		testList.insertAfter(testList.getFirstNode().getNext(), "v");
		testList.insertAfter(testList.getFirstNode(), "j");
		String print = testList.toString();
		System.out.println(print);
		
		
		
	}

}
