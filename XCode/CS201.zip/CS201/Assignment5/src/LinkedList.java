public class LinkedList<T>
{
    private LinkedListNode<T> head;
    
    public LinkedList()
    {
    	head = new LinkedListNode<T>(null);
    }
    
    /**
     * Get data stored in head node of list.
     **/
    public T getFirst()
    {
        return(head.getData());
    }
    
    /**
     * Get the head node of the list.
     **/
    public LinkedListNode<T> getFirstNode()
    {
        return(head);
    }
    
    /**
     * Get data stored in tail node of list.
     **/
    public T getLast()
    {
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getData() != null)
        {
            lastNode = lastNode.getNext();
        }
        
        return lastNode.getData();
    }
    
    /**
     * Get the tail node of the list.
     **/
    public LinkedListNode<T> getLastNode()
    {
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getData() != null)
        {
            lastNode = lastNode.getNext();
        }
        
        return lastNode;
    }
    
    /**
     * Insert a new node with data at the head of the list.
     **/
    public void insertFirst( T data )
    {
        LinkedListNode<T> newFirst = new LinkedListNode<T>(data);
        
        if(isEmpty() == true)
        {
            head = newFirst;
        }
        
        else
        {
            newFirst.setNext(head);
        
            head = newFirst;
        }
    }
    
    /**
     * Insert a new node with data after currentNode
     **/
    public void insertAfter( LinkedListNode<T> currentNode, T data )
    {
        LinkedListNode<T> newNode = new LinkedListNode<T>(data);
        
        newNode.setNext(currentNode.getNext());
        
        currentNode.setNext(newNode);
    }
    
    /**
     * Insert a new node with data at the tail of the list.
     **/
    public void insertLast( T data )
    {
        LinkedListNode<T> newNode = new LinkedListNode<T>(data);
        
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getData() != null)
        {
            lastNode = lastNode.getNext();
        }
        
        lastNode.setNext(newNode);
    }
    
    /**
     * Remove head node
     **/
    public void deleteFirst()
    {
        LinkedListNode<T> deleteNode = head;
        head = head.getNext();
        deleteNode.setNext(null);
        
    }
    
    /**
     * Remove tail node
     **/
    public void deleteLast()
    {
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getNext().getData() != null)
        {
            lastNode = lastNode.getNext();
        }
        
        lastNode.setNext(null);
        
    }
    
    /**
     * Remove node following currentNode
     * If no node exists (i.e., currentNode is the tail), do nothing
     **/
    public void deleteNext( LinkedListNode<T> currentNode )
    {
        if (currentNode.getNext() != null)
        {
            LinkedListNode<T> deleteNode = currentNode.getNext();
            
            currentNode.setNext(deleteNode.getNext());
            
            deleteNode.setNext(null);
        }
    }
    
    /**
     * Return the number of nodes in this list.
     **/
    public int size()
    {
        int listLength = 1;
        
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getData() != null)
        {
            lastNode = lastNode.getNext();
            
            ++listLength;
        }
        
        return listLength;
    }
    
    /**
     * Check if list is empty.
     * @return true if list contains no items.
     **/
    public boolean isEmpty()
    {
        if(head == null)
            return true;
        else
            return false;
    }
    
    /**
     * Return a String representation of the list.
     **/
    public String toString()
    {
        String listString = "";
        
        listString.equals(head.getData());
        
        LinkedListNode<T> lastNode = head;
        
        while(lastNode.getData() != null)
        {
            lastNode = lastNode.getNext();
            
            listString.equals(listString + " => " + lastNode.getData());
        }
        
        return listString;
    }
}